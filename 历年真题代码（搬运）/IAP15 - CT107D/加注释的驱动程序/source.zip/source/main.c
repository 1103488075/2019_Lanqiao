/********************************************
ʵ��������IAP15F2K61S2@11.0592MHz
ʵ��ƽ̨��CT107D��Ƭ��������
���ڣ�Doing
���ߣ����Ϲ�ҵ��ѧ �ΰ
*********************************************/
#include "stc15.h"
#include "config.h"
#include "common.h"
#include "key.h"
#include "usart.h"
#include "smg.h"
#include "onewire.h"
#include "stdio.h"
#include "DS1302.h"
#include "iic.h"

void main()
{
	uchar a;
	UartInit();
//	Timer0Init();
	CloBzLED();
	DS1302Init();
	while(1)
	{
//		if(SmgSta)
//		{
//			Digit(TempSmgChuli(Ds18B20ReadTemp()),2,0);
//		}
//		else
//		Digit(TestNumber,0,0);
//		KeyDrive();
		
//		Ds1302_Single_Byte_Write(0x80,0x45);
//		uartdata = Ds1302_Single_Byte_Read(0x80);
//		SendData(uartdata);
//		delay_ms(200);	  //�ײ����

//		Ds1302ReadTime();
//		SendData(Ds1302_Time[0]);
//		delay_ms(200);
//		delay_ms(200);

		IICWrite(0x00,0x55);
		
		a = IICRead(0x00);
		delay_ms(200);
		SendData(a);
	}
}

void Timer0Int() interrupt 1
{
	static uint k = 0;
	k++;
	if(k % 5 == 0 )	   //0.5ms
	{
		KeyScan();
		DigitPlay(3);
		k = 0;
	}
	
}