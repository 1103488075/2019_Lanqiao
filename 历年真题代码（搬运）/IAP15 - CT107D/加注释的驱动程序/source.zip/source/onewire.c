//�ٷ�����
#include "onewire.h"
#include "common.h"

//��������ʱ����
void Delay_OneWire(unsigned int t)
{
  uchar i = 0;
  while(t--)
  {
  	for(i = 0;i<12;i++);
  }
}

//DS18B20оƬ��ʼ��
bit Init_DS18B20(void)
{
	bit initflag = 0;
	DQ = 1;
	Delay_OneWire(12);
	DQ = 0;
	Delay_OneWire(80); 
	DQ = 1;
	Delay_OneWire(10); 
	initflag = DQ;    
	Delay_OneWire(5);
  
	return initflag;
}

//ͨ����������DS18B20дһ���ֽ�
void Write_DS18B20(unsigned char dat)
{
	unsigned char i;
	for(i=0;i<8;i++)
	{
		DQ = 0;
		DQ = dat&0x01;
		Delay_OneWire(5);
		DQ = 1;
		dat >>= 1;
	}
	Delay_OneWire(5);
}

//��DS18B20��ȡһ���ֽ�
unsigned char Read_DS18B20(void)
{
	unsigned char i;
	unsigned char dat;
  
	for(i=0;i<8;i++)
	{
		DQ = 0;
		dat >>= 1;
		DQ = 1;
		if(DQ)
		{
			dat |= 0x80;
		}	    
		Delay_OneWire(5);
	}
	return dat;
}

int Ds18B20ReadTemp()
{
	int temp;
	uchar tempTh,tempTl;
	Init_DS18B20();
	Write_DS18B20(OW_SKIP_ROM);
	Write_DS18B20(DS18B20_CONVERT);
	delay_ms(200);

	Init_DS18B20();
	Write_DS18B20(OW_SKIP_ROM);
	Write_DS18B20(DS18B20_READ);
	tempTl = Read_DS18B20();
	tempTh = Read_DS18B20();
	temp = tempTh<<8;
	temp |= tempTl;
	return temp;
}
float TempSmgChuli(int temp)
{
	float temperature = 0;
	if(temp >= 0)
	{
		temperature = temp*6.25;	
	}	
	else if(temp < 0)
	{
		temperature = (~(temp-1))*6.25;	
	}
	return temperature;
}