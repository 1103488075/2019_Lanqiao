#ifndef _CONFIG_H_
#define _CONFIG_H_

#include "stc15.h"
typedef unsigned int uint;
typedef unsigned char uchar;

#endif
